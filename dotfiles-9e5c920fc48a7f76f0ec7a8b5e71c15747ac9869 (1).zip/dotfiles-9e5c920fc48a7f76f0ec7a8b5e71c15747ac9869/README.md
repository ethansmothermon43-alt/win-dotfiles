# dotfiles
These files are my personal customization files that I use to personalize my Windows and/or Linux desktop experience.